Add hero-fashion.mp4 and other campaign videos here when ready. The MVP currently uses image fallbacks.
