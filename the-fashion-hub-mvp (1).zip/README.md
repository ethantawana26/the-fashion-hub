# THE FUSHION HUB — MVP

A 3-page React/Vite fashion website designed for Visual Studio Code and Google Firebase Hosting.

## Pages
- `/` Home
- `/collections` Collections
- `/about` About & Contact

## Included
- Attached THE FASHION HUB logo and store images
- Login/access gate with demo OTP
- Local visitor record in browser localStorage
- Responsive luxury black/gold/white design
- CSS 3D fashion display and tilt cards
- Raylight-ready iframe slot using `VITE_RAYLIGHT_EMBED_URL`
- Product filtering and item modal
- Chatbot UI on every page
- Contact form that opens an email draft
- WhatsApp and click-to-call links
- Firebase Hosting configuration

## Run in VS Code
1. Install Node.js LTS.
2. Open this folder in VS Code.
3. Open Terminal.
4. Run `npm install`
5. Run `npm run dev`
6. Open the local address Vite prints, normally `http://localhost:5173`.

## Demo login
Enter any name, email and phone. The MVP generates a demo OTP on screen. In a real production site, replace this with Firebase Phone Authentication or another verified OTP service. Do not trust a client-only OTP for real authentication.

## Google hosting (Firebase)
Install Firebase CLI:
`npm install -g firebase-tools`

Sign in:
`firebase login`

Create/select a Firebase project:
`firebase init hosting`

For the existing `firebase.json`, choose the `dist` directory when prompted if setup asks.

Build:
`npm run build`

Deploy:
`firebase deploy`

Firebase will provide a public HTTPS URL.

## Important production upgrades
- Store users in Firestore instead of localStorage.
- Use Firebase Auth for real OTP verification.
- Use a secure backend/Cloud Function for emails.
- Store real products and stock in Firestore.
- Connect a real chatbot API securely from a backend.
- Replace placeholder product photos with owned/licensed product photos.
- Replace the Raylight iframe URL with the embed URL provided by Raylight.app.

## Contact details supplied for this MVP
Owner: Cedella Whata
Email: ethantawana26@gmail.com
Phone: 0780043130

The spelling requested in the latest brief is "THE FUSHION HUB".
