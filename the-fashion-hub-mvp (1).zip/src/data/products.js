import warm from "../assets/store-warm.jpg";
import bright from "../assets/store-bright.jpg";
import denim from "../assets/denim-store.jpg";
import vintage from "../assets/vintage-store.jpg";

const base = [
  ["Obsidian Tailored Set","Men","Tailoring","$120"],
  ["Midnight Denim","Men","Denim","$70"],
  ["Fusion Street Jacket","Men","Streetwear","$95"],
  ["Urban Charcoal Tee","Men","Streetwear","$35"],
  ["Champagne Evening Dress","Women","Dresses","$140"],
  ["Silk Motion Dress","Women","Dresses","$155"],
  ["Sculpted Knitwear","Women","Knitwear","$85"],
  ["Faux Fur Statement Coat","Women","Outerwear","$180"],
  ["Fusion Kids Set","Kids","Kidswear","$45"],
  ["Mini Street Jacket","Kids","Kidswear","$50"],
  ["Classic White Sneaker","Accessories","Shoes","$80"],
  ["Future Runner","Accessories","Shoes","$110"],
  ["Crown Signature Hat","Accessories","Hats","$35"],
  ["Leather Crossbody","Accessories","Bags","$65"],
  ["Metal Frame Shades","Accessories","Accessories","$30"],
  ["Fusion Chain","Accessories","Jewellery","$40"],
  ["African Print Fusion","Women","African-inspired","$90"],
  ["Heritage Shirt","Men","African-inspired","$75"],
  ["Monochrome Cargo","Men","Streetwear","$80"],
  ["Velvet Night Look","Women","Evening","$160"],
  ["Studio Overshirt","Men","Outerwear","$105"],
  ["Soft Neutral Set","Women","Knitwear","$100"],
  ["Classic Blue Denim","Men","Denim","$65"],
  ["Statement Faux Fur","Women","Outerwear","$175"]
];

const images = [warm, bright, denim, vintage];

export const products = base.map((p, i) => ({
  id: i + 1,
  name: p[0],
  category: p[1],
  type: p[2],
  price: p[3],
  image: images[i % images.length],
  description: "A curated THE FUSHION HUB piece with a modern editorial feel."
}));
