import React from "react";

export default function ProductModal({ product, onClose }) {
  if (!product) return null;
  const body = `Hello THE FUSHION HUB,%0A%0AItem: ${encodeURIComponent(product.name)}%0AName:%0APhone:%0AMessage:`;
  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="product-modal" onClick={(e) => e.stopPropagation()}>
        <button className="close-modal" onClick={onClose}>×</button>
        <div className="modal-image"><img src={product.image} alt={product.name} /><div className="mini-3d">3D</div></div>
        <div className="modal-copy">
          <span className="eyebrow">{product.category} / {product.type}</span>
          <h2>{product.name}</h2>
          <p className="muted">{product.description}</p>
          <strong className="price">{product.price}</strong>
          <a className="gold-btn inline-btn" href={`mailto:ethantawana26@gmail.com?subject=Order%20or%20Enquiry&body=${body}`}>Order / Enquire ↗</a>
          <a className="outline-btn" href="https://wa.me/263780043130" target="_blank" rel="noreferrer">WhatsApp ↗</a>
        </div>
      </div>
    </div>
  );
}
