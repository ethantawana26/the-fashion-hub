import React, { useState } from "react";
import logo from "../assets/logo.jpg";

export default function LoginGate({ onLogin }) {
  const [step, setStep] = useState("details");
  const [form, setForm] = useState({ name: "", email: "", phone: "" });
  const [otp, setOtp] = useState("");
  const [demoOtp, setDemoOtp] = useState("");

  const update = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const requestOtp = (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.phone) return;
    const code = String(Math.floor(100000 + Math.random() * 900000));
    setDemoOtp(code);
    setStep("otp");
  };

  const verify = (e) => {
    e.preventDefault();
    if (otp !== demoOtp) return;
    const visitor = { ...form, loggedInAt: new Date().toISOString() };
    localStorage.setItem("fushionHubUser", JSON.stringify(visitor));
    const visitors = JSON.parse(localStorage.getItem("fushionHubVisitors") || "[]");
    localStorage.setItem("fushionHubVisitors", JSON.stringify([...visitors, visitor]));
    onLogin(visitor);
  };

  return (
    <main className="login-screen">
      <div className="login-card">
        <div className="login-visual">
          <img src={logo} alt="THE FUSHION HUB logo" />
          <div className="login-orbit" />
        </div>
        {step === "details" ? (
          <form onSubmit={requestOtp}>
            <span className="eyebrow">Private access</span>
            <h1>Enter the world of fusion.</h1>
            <p className="muted">Sign in before exploring the collection.</p>
            <label>Full name<input name="name" value={form.name} onChange={update} placeholder="Your name" /></label>
            <label>Email<input name="email" type="email" value={form.email} onChange={update} placeholder="you@example.com" /></label>
            <label>Phone number<input name="phone" value={form.phone} onChange={update} placeholder="078..." /></label>
            <button className="gold-btn" type="submit">Continue ↗</button>
          </form>
        ) : (
          <form onSubmit={verify}>
            <span className="eyebrow">Verification</span>
            <h1>Enter your code.</h1>
            <p className="muted">MVP demo code: <strong className="otp-code">{demoOtp}</strong></p>
            <input className="otp-input" inputMode="numeric" maxLength="6" value={otp} onChange={(e) => setOtp(e.target.value)} placeholder="6-digit code" />
            <button className="gold-btn" type="submit">Verify & Enter ↗</button>
            <button type="button" className="text-btn" onClick={() => setStep("details")}>Back</button>
          </form>
        )}
        <small className="legal-note">Demo authentication only. Use a real OTP provider before launch.</small>
      </div>
    </main>
  );
}
