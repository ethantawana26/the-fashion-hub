import React from "react";

export default function ThreeScene({ className = "" }) {
  const raylight = import.meta.env.VITE_RAYLIGHT_EMBED_URL;
  if (raylight) {
    return (
      <div className={`raylight-frame ${className}`}>
        <iframe
          title="THE FUSHION HUB 3D scene"
          src={raylight}
          loading="lazy"
          allow="autoplay; fullscreen; xr-spatial-tracking"
        />
      </div>
    );
  }

  return (
    <div className={`three-scene ${className}`} aria-hidden="true">
      <div className="orbital orbital-a" />
      <div className="orbital orbital-b" />
      <div className="fashion-form">
        <div className="form-neck" />
        <div className="form-body" />
        <div className="form-skirt" />
      </div>
      <div className="scene-glow" />
    </div>
  );
}
