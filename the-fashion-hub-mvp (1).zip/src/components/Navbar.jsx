import React, { useEffect, useState } from "react";
import { Link, NavLink } from "react-router-dom";
import logo from "../assets/logo.jpg";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);
  const close = () => setOpen(false);
  return (
    <header className={`nav ${scrolled ? "scrolled" : ""}`}>
      <Link to="/" className="brand" onClick={close}>
        <img src={logo} alt="" />
        <span>THE FUSHION HUB</span>
      </Link>
      <button className="menu-btn" onClick={() => setOpen(!open)} aria-label="Toggle menu">☰</button>
      <nav className={open ? "nav-links open" : "nav-links"}>
        <NavLink to="/" onClick={close}>Home</NavLink>
        <NavLink to="/collections" onClick={close}>Collections</NavLink>
        <NavLink to="/about" onClick={close}>About & Contact</NavLink>
      </nav>
    </header>
  );
}
