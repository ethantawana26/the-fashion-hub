import React from "react";
import { Link } from "react-router-dom";
export default function Footer() {
  return <footer className="footer">
    <div><span className="eyebrow">THE FUSHION HUB</span><h2>Where Style Meets Fusion.</h2></div>
    <div className="footer-links"><Link to="/">Home</Link><Link to="/collections">Collections</Link><Link to="/about">About</Link><a href="mailto:ethantawana26@gmail.com">Email</a><a href="https://wa.me/263780043130" target="_blank" rel="noreferrer">WhatsApp</a></div>
    <small>Owner: Cedella Whata · 0780043130 · © 2026 THE FUSHION HUB</small>
  </footer>;
}
