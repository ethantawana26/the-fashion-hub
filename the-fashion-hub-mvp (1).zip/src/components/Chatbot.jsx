import React, { useState } from "react";

export default function Chatbot({ user }) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    { from: "bot", text: `Welcome${user?.name ? `, ${user.name}` : ""}. Ask me about sizes, prices, availability, delivery or orders.` }
  ]);
  const [input, setInput] = useState("");

  const send = (e) => {
    e.preventDefault();
    const q = input.trim();
    if (!q) return;
    const lower = q.toLowerCase();
    let answer = "I can help with products, prices, sizes, availability, delivery and enquiries. For a human, call 0780043130.";
    if (lower.includes("price") || lower.includes("cost")) answer = "Prices are shown on the Collections page. Tell me the item name and I can help you prepare an enquiry.";
    else if (lower.includes("size")) answer = "Tell me the item and your preferred size. A human can confirm exact stock.";
    else if (lower.includes("delivery")) answer = "Delivery details are confirmed when an order enquiry is placed. Include your location in your message.";
    else if (lower.includes("human") || lower.includes("owner") || lower.includes("call")) answer = "You can call or WhatsApp Cedella Whata on 0780043130.";
    else if (lower.includes("order") || lower.includes("buy")) answer = "Please give me your name, phone number and the item you want. I can prepare an enquiry for the owner.";
    setMessages((m) => [...m, { from: "user", text: q }, { from: "bot", text: answer }]);
    setInput("");
  };

  const emailEnquiry = () => {
    window.location.href = "mailto:ethantawana26@gmail.com?subject=THE%20FUSHION%20HUB%20Enquiry&body=Name:%0APhone:%0AItem:%0AMessage:";
  };

  return (
    <>
      <button className="chat-fab" onClick={() => setOpen(!open)} aria-label="Open chat">✦</button>
      {open && (
        <aside className="chat-panel">
          <div className="chat-head"><strong>FUSHION ASSIST</strong><button onClick={() => setOpen(false)}>×</button></div>
          <div className="chat-body">{messages.map((m, i) => <div key={i} className={`bubble ${m.from}`}>{m.text}</div>)}</div>
          <button className="chat-email" onClick={emailEnquiry}>Prepare an email enquiry ↗</button>
          <form className="chat-input" onSubmit={send}><input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask something..." /><button>→</button></form>
        </aside>
      )}
    </>
  );
}
