import React, { useEffect, useState } from "react";
import { Routes, Route, useNavigate } from "react-router-dom";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import Chatbot from "./components/Chatbot";
import LoginGate from "./components/LoginGate";
import ThreeScene from "./components/ThreeScene";
import ProductModal from "./components/ProductModal";
import { products } from "./data/products";
import warm from "./assets/store-warm.jpg";
import bright from "./assets/store-bright.jpg";
import denim from "./assets/denim-store.jpg";
import vintage from "./assets/vintage-store.jpg";

function Shell({ user }) {
  return <><Navbar /><Routes>
    <Route path="/" element={<Home />} />
    <Route path="/collections" element={<Collections />} />
    <Route path="/about" element={<About />} />
  </Routes><Chatbot user={user} /><Footer /></>;
}

function Home() {
  const navigate = useNavigate();
  return <main>
    <section className="hero">
      <div className="hero-bg" style={{backgroundImage:`linear-gradient(90deg,rgba(0,0,0,.88),rgba(0,0,0,.28)),url(${warm})`}} />
      <ThreeScene className="hero-3d" />
      <div className="hero-content">
        <span className="eyebrow">Wear your creativity</span>
        <h1>Where Style<br/><em>Meets Fusion.</em></h1>
        <p>Curated fashion for people who want clothing to feel expressive, modern and unforgettable.</p>
        <button className="gold-btn" onClick={() => navigate("/collections")}>Shop the Collection ↗</button>
      </div>
      <div className="hero-meta"><span>THE FUSHION HUB</span><span>Campaign 01 / 03</span></div>
    </section>

    <section className="section intro">
      <div><span className="eyebrow">The house</span><h2>Fashion with a point of view.</h2></div>
      <p>THE FUSHION HUB brings together men's, women's, kids' and accessory styles in a single visual destination. The experience is designed around bold imagery, refined details and easy enquiries.</p>
    </section>

    <section className="section">
      <div className="section-head"><div><span className="eyebrow">Featured</span><h2>Explore the collections</h2></div><button className="text-btn" onClick={() => navigate("/collections")}>View all ↗</button></div>
      <div className="feature-grid">{[
        ["Men",denim],["Women",bright],["Kids",warm],["Accessories",vintage]
      ].map(([name,img],i)=><article className="feature-card tilt" key={name} style={{"--i":i}} onClick={()=>navigate("/collections")}><img src={img} alt={`${name} fashion at THE FUSHION HUB`}/><div><span>0{i+1}</span><h3>{name}</h3></div></article>)}</div>
    </section>

    <section className="section">
      <div className="section-head"><div><span className="eyebrow">New arrivals</span><h2>Selected pieces.</h2></div></div>
      <div className="new-grid">{products.slice(0,6).map(p=><article className="product-mini" key={p.id}><img src={p.image} alt={p.name}/><div><span>{p.category}</span><h3>{p.name}</h3><b>{p.price}</b></div></article>)}</div>
    </section>

    <section className="store-banner">
      <img src={bright} alt="Bright fashion store interior" />
      <div><span className="eyebrow">Inside the store</span><h2>Come in. Look around. Find your fusion.</h2><button className="gold-btn" onClick={()=>navigate("/about")}>Visit & Contact ↗</button></div>
    </section>
  </main>;
}

function Collections() {
  const [filter,setFilter] = useState("All");
  const [selected,setSelected] = useState(null);
  const filters=["All","Men","Women","Kids","Accessories"];
  const shown=filter==="All"?products:products.filter(p=>p.category===filter);
  return <main className="page">
    <section className="page-hero"><span className="eyebrow">The edit / 2026</span><h1>Collections.</h1><p>Men, women, kids and accessories — curated in one place.</p></section>
    <section className="section collection-section">
      <div className="filter-bar">{filters.map(f=><button key={f} className={filter===f?"active":""} onClick={()=>setFilter(f)}>{f}</button>)}</div>
      <div className="product-grid">{shown.map((p,i)=><article className="product-card" key={p.id} onClick={()=>setSelected(p)}>
        <div className="product-img"><img src={p.image} alt={p.name}/><span>{String(i+1).padStart(2,"0")}</span></div>
        <div className="product-info"><div><span>{p.category} · {p.type}</span><h3>{p.name}</h3></div><b>{p.price}</b></div>
      </article>)}</div>
    </section>
    <ProductModal product={selected} onClose={()=>setSelected(null)} />
  </main>;
}

function About() {
  return <main className="page">
    <section className="page-hero"><span className="eyebrow">The story</span><h1>About the house.</h1><p>A modern fashion retail concept led by Cedella Whata.</p></section>
    <section className="section about-grid">
      <img className="about-photo" src={vintage} alt="THE FUSHION HUB fashion store" />
      <div><span className="eyebrow">Our philosophy</span><h2>Style should feel personal.</h2><p>THE FUSHION HUB is built around the idea of fusion: different influences, silhouettes and identities coming together to create a style that feels individual.</p><div className="principles">{["Creativity","Craft","Confidence","Timelessness"].map((x,i)=><div key={x}><b>0{i+1}</b><h3>{x}</h3><p>Designed to make the everyday feel considered.</p></div>)}</div></div>
    </section>
    <section className="section contact-grid">
      <div><span className="eyebrow">Contact</span><h2>Let's talk fashion.</h2><p className="muted">For orders, availability, sizing and delivery questions, contact the owner directly.</p><div className="contact-list"><a href="tel:+263780043130">0780043130 ↗</a><a href="https://wa.me/263780043130" target="_blank" rel="noreferrer">WhatsApp ↗</a><a href="mailto:ethantawana26@gmail.com">ethantawana26@gmail.com ↗</a></div></div>
      <form className="contact-form" onSubmit={(e)=>{e.preventDefault(); const f=new FormData(e.currentTarget); const body=`Name: ${f.get("name")}%0APhone: ${f.get("phone")}%0AMessage: ${f.get("message")}`; window.location.href=`mailto:ethantawana26@gmail.com?subject=THE%20FUSHION%20HUB%20Contact&body=${body}`;}}>
        <label>Name<input name="name" required placeholder="Your name"/></label><label>Phone<input name="phone" required placeholder="078..."/></label><label>Message<textarea name="message" required rows="5" placeholder="How can we help?"/></label><button className="gold-btn" type="submit">Send enquiry ↗</button>
      </form>
    </section>
  </main>;
}

export default function App() {
  const [user,setUser]=useState(null);
  useEffect(()=>{const saved=localStorage.getItem("fushionHubUser"); if(saved) setUser(JSON.parse(saved));},[]);
  if(!user) return <LoginGate onLogin={setUser}/>;
  return <Shell user={user}/>;
}
